#!/bin/sh
#************************************Author Information**************************************
				
#				     Danula Godagama 
#			    	 danula.godagama@uky.edu 
#			        University of Kentucky 
#				       04/02/2020 

#**************************************File Information***************************************
#				       Install.sh
#Run with sudo ./Install.sh
#This shell script compile and install the SIS3153 Kmax driver components.
#This script should be run from this directory(SIS3153_Kmax_Driver).
#It assumes that the Kmax_Stuff folder is located in the home directory.
#libSIS3153.so need libusb package installed in your computer.
#JAVA-JDK version 1.8 or above to compile SIS3153 Java class libarary 
#*********************************************************************************************
cp ./libSIS3153.so ~/Kmax_Stuff/Extensions/Linux-amd64
cp ./SIS3153.jar ~/Kmax_Stuff/Extensions/Linux-amd64
cp ./SIS3153_Controller.mdr ~/Kmax_Stuff/Extensions/VME.MDRL
chmod +x ~/Kmax_Stuff/Extensions/Linux-amd64/SIS3153.jar
